This is the latest version of the Jinja2 syntax file for vim with the ability to detect either HTML or Jinja.

There are two reasons I made this repository:

- The version of this vim addon is out-of-date on vimscripts.

- I wanted to manage this syntax file with vim-addons-manager or whatever other vim plugins managers there are.

If the plugin is overzealous in detecting the Jinja syntax, send me the template it shouldn't have matched.
